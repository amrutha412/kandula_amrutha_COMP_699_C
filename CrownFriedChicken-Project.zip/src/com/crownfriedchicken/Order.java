package com.crownfriedchicken;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private List<String> items = new ArrayList<>();
    private double total;

    public void addItem(String item, double price) {
        items.add(item);
        total += price;
    }

    public double getTotal() {
        return total;
    }

    public void printOrder() {
        System.out.println("Order Summary:");
        for (String item : items) {
            System.out.println("- " + item);
        }
        System.out.println("Total: $" + total);
    }
}