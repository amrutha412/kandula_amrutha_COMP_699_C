package com.crownfriedchicken;

public class Main {
    public static void main(String[] args) {
        Reservation res = new Reservation("John Doe", "2025-05-01", "7:00 PM");
        res.confirmReservation();

        Order order = new Order();
        order.addItem("Fried Chicken", 12.99);
        order.addItem("Fries", 3.99);
        order.printOrder();
    }
}