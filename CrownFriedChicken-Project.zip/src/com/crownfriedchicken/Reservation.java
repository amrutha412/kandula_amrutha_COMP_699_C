package com.crownfriedchicken;

public class Reservation {
    private String customerName;
    private String date;
    private String time;

    public Reservation(String customerName, String date, String time) {
        this.customerName = customerName;
        this.date = date;
        this.time = time;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public void confirmReservation() {
        System.out.println("Reservation confirmed for " + customerName + " on " + date + " at " + time);
    }
}